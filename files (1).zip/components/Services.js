const items = [
  { title: 'Swedish Massage', desc: 'Classic full-body massage for relaxation.', time: '60 min' },
  { title: 'Hot Stone Therapy', desc: 'Warm stones to soothe muscles.', time: '75 min' },
  { title: 'Facial & Glow', desc: 'Hydrating facial for radiant skin.', time: '50 min' },
  { title: 'Couples Retreat', desc: 'Shared relaxation experience.', time: '90 min' },
];

export default function Services(){
  return (
    <section id="services" className="container py-12">
      <h2 className="text-2xl font-semibold mb-6">Our Services</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((s)=>(
          <div key={s.title} className="card">
            <h3 className="text-lg font-bold">{s.title}</h3>
            <p className="text-slate-600 mt-2">{s.desc}</p>
            <div className="mt-4 text-sm text-slate-500 font-medium">{s.time}</div>
          </div>
        ))}
      </div>
    </section>
  );
}