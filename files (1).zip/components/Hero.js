export default function Hero(){
  return (
    <section className="py-16 text-center bg-gradient-to-b from-black/40 to-black/10 text-white">
      <div className="container">
        <h1 className="text-4xl font-extrabold mb-4">Relax. Rebalance. Renew.</h1>
        <p className="max-w-2xl mx-auto text-lg mb-6">Personalized wellness treatments for a healthier, calmer you.</p>
        <a href="#booking" className="btn">Book Now</a>
      </div>
    </section>
  );
}