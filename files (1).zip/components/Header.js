import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header bg-[url('https://images.unsplash.com/photo-1556228452-3f3f3a69d647?q=80&w=2000&auto=format&fit=crop')] bg-cover text-white">
      <div className="container flex items-center justify-between py-4">
        <Link href="/"><a className="text-xl font-bold">Culture Unisex Wellness</a></Link>
        <nav className="hidden md:flex gap-4">
          <a href="#about" className="hover:underline">About</a>
          <a href="#services" className="hover:underline">Services</a>
          <a href="#gallery" className="hover:underline">Gallery</a>
          <a href="#booking" className="hover:underline">Booking</a>
        </nav>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-expanded={open}>☰</button>
      </div>

      {open && (
        <div className="md:hidden bg-white text-slate-800">
          <div className="container py-4 flex flex-col gap-3">
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#gallery">Gallery</a>
            <a href="#booking">Booking</a>
          </div>
        </div>
      )}
    </header>
  );
}