const imgs = [
  'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1200&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?q=80&w=1200&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1200&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1200&auto=format&fit=crop'
];

export default function Gallery(){
  return (
    <section id="gallery" className="container py-12">
      <h2 className="text-2xl font-semibold mb-6">Gallery</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {imgs.map((u,i)=>(
          <img key={i} src={u} alt={`spa-${i}`} className="w-full h-44 object-cover rounded-lg shadow" />
        ))}
      </div>
    </section>
  );
}