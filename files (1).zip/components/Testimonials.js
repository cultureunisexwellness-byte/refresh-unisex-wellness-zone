const reviews = [
  { text: "A beautiful, calming experience — the staff truly listened to my needs.", author: "Maya R." },
  { text: "Best facial I've had. My skin glowed for days!", author:](#)*
