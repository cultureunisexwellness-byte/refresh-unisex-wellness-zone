import Head from 'next/head';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Services from '../components/Services';
import Gallery from '../components/Gallery';
import Testimonials from '../components/Testimonials';
import Booking from '../components/Booking';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <>
      <Head>
        <title>Culture Unisex Wellness — Relax. Rebalance. Renew.</title>
        <meta name="description" content="Professional spa services: massages, facials, couples treatments and more. Book online." />
      </Head>

      <Header />
      <main>
        <Hero />
        <section id="about" className="container">
          <h2 className="text-2xl font-semibold mb-2">About Culture Unisex Wellness</h2>
          <p className="text-slate-600">We blend ancient therapies with modern wellness to help you feel your best. Experienced therapists, premium products, and a calm environment.</p>
        </section>

        <Services />
        <Gallery />
        <Testimonials />
        <Booking />

      </main>
      <Footer />
    </>
  );
}